This is JavaScript

making changes in the JS  