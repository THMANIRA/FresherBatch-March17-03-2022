making changes

making changes for the JS assignments purpose


Again making changes in the README for the JS assignments




make change in the next lines dont in gthe same line



Minor changes in the README for the JS purpose