﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public interface IStaffRepository
    {
        Task<IEnumerable<Staff>> GetStaffs();
        Task<Staff> Create(Staff staff);
        Task Update(Staff staff);
        Task Delete(int UserId);
        Task<Staff> Get(int UserId);
    }
}
