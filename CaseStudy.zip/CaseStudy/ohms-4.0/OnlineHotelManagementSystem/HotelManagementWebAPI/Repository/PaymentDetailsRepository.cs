﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;

namespace HotelManagementWebAPI.Repository
{
    public class PaymentDetailsRepository : IPaymentDetailsData<PaymentDetails>
    {
        private readonly OnlineHotelManagementSystemContext _onlineHotelManagementContext;

        public PaymentDetailsRepository(OnlineHotelManagementSystemContext onlineHotelManagementContext)
        {
            _onlineHotelManagementContext = onlineHotelManagementContext;
        }
        public async Task<PaymentDetails> Get(int PaymentId)
        {
            return await _onlineHotelManagementContext.PaymentDetails.FindAsync(PaymentId);
        }
        public async Task<PaymentDetails> AddPaymentDetails(PaymentDetailsData paymentData)
        {
            var paymentDetails = new PaymentDetails()
            {
                PaymentId = paymentData.PaymentId,
                PaymentTime = paymentData.PaymentTime,
                PaymentMethod = paymentData.PaymentMethod,
                MemberCode = paymentData.MemberCode,
                InvoiceId =paymentData.InvoiceId,
                Total = paymentData.Total,
            };
            if (paymentDetails == null)
            {
                return null;
            }
            await _onlineHotelManagementContext.PaymentDetails.AddAsync(paymentDetails);
            await _onlineHotelManagementContext.SaveChangesAsync();
            return paymentDetails;
        }
        public async Task Delete(int PaymentId)
        {
            var paymentDetailsToDelete = await _onlineHotelManagementContext.PaymentDetails.FindAsync(PaymentId);
            _onlineHotelManagementContext.PaymentDetails.Remove(paymentDetailsToDelete);
            _onlineHotelManagementContext.SaveChanges();
        }
    }
}
