﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;

namespace HotelManagementWebAPI.Interface
{
    public interface IRoomData<T>
    {
        Task<T> AddRoom(RoomData roomData);
        Task<T> Get(int roomId);
    }
}
