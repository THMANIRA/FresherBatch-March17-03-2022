﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class TypeOfRoom
    {
        public TypeOfRoom()
        {
            Room = new HashSet<Room>();
        }

        public string RoomType { get; set; }
        public int Adults { get; set; }
        public int Child { get; set; }
        public int StandardPrice { get; set; }

        public virtual ICollection<Room> Room { get; set; }
    }
}
