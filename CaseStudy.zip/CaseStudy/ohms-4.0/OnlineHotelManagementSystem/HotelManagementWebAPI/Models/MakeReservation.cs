﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class MakeReservation
    {
        public MakeReservation()
        {
            ServicesBill = new HashSet<ServicesBill>();
        }

        public int ReservationCode { get; set; }
        public int? RoomId { get; set; }
        public int? MemberCode { get; set; }
        public DateTime CheckInTime { get; set; }
        public DateTime CheckOutTime { get; set; }
        public int NoOfNights { get; set; }
        public int RoomPrice { get; set; }

        public virtual Guest MemberCodeNavigation { get; set; }
        public virtual Room Room { get; set; }
        public virtual ICollection<ServicesBill> ServicesBill { get; set; }
    }
}
