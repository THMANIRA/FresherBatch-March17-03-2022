﻿using System;
using System.Collections.Generic;

namespace HotelManagementWebAPI.Models
{
    public partial class Inventory
    {
        public int InventoryId { get; set; }
        public string InventoryName { get; set; }
        public int Quantity { get; set; }
        public int UnitPrice { get; set; }
    }
}
