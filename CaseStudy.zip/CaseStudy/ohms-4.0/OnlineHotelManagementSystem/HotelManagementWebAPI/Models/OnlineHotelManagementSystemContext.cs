﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace HotelManagementWebAPI.Models
{
    public partial class OnlineHotelManagementSystemContext : DbContext
    {
        public OnlineHotelManagementSystemContext()
        {
        }

        public OnlineHotelManagementSystemContext(DbContextOptions<OnlineHotelManagementSystemContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Guest> Guest { get; set; }
        public virtual DbSet<Inventory> Inventory { get; set; }
        public virtual DbSet<Invoice> Invoice { get; set; }
        public virtual DbSet<MakeReservation> MakeReservation { get; set; }
        public virtual DbSet<PaymentDetails> PaymentDetails { get; set; }
        public virtual DbSet<Room> Room { get; set; }
        public virtual DbSet<ServicesBill> ServicesBill { get; set; }
        public virtual DbSet<Staff> Staff { get; set; }
        public virtual DbSet<TypeOfRoom> TypeOfRoom { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=SaikiranJillaV\\MSSQLSERVER01;Database=OnlineHotelManagementSystem;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Guest>(entity =>
            {
                entity.HasKey(e => e.MemberCode)
                    .HasName("PK__Guest__84CA637649D41163");

                entity.HasIndex(e => e.Email)
                    .HasName("UQ__Guest__A9D10534040B824D")
                    .IsUnique();

                entity.HasIndex(e => e.MobileNumber)
                    .HasName("UQ__Guest__250375B125815437")
                    .IsUnique();

                entity.Property(e => e.Citizenship)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.DrivingLicence)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.MobileNumber)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Occupation)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Pincode)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Inventory>(entity =>
            {
                entity.Property(e => e.InventoryName)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Invoice>(entity =>
            {
                entity.HasOne(d => d.MemberCodeNavigation)
                    .WithMany(p => p.Invoice)
                    .HasForeignKey(d => d.MemberCode)
                    .HasConstraintName("FK__Invoice__MemberC__34C8D9D1");
            });

            modelBuilder.Entity<MakeReservation>(entity =>
            {
                entity.HasKey(e => e.ReservationCode)
                    .HasName("PK__MakeRese__2081C0BA462E169F");

                entity.Property(e => e.CheckInTime).HasColumnType("datetime");

                entity.Property(e => e.CheckOutTime).HasColumnType("datetime");

                entity.HasOne(d => d.MemberCodeNavigation)
                    .WithMany(p => p.MakeReservation)
                    .HasForeignKey(d => d.MemberCode)
                    .HasConstraintName("FK__MakeReser__Membe__2E1BDC42");

                entity.HasOne(d => d.Room)
                    .WithMany(p => p.MakeReservation)
                    .HasForeignKey(d => d.RoomId)
                    .HasConstraintName("FK__MakeReser__RoomI__2D27B809");
            });

            modelBuilder.Entity<PaymentDetails>(entity =>
            {
                entity.HasKey(e => e.PaymentId)
                    .HasName("PK__PaymentD__9B556A380B39E702");

                entity.Property(e => e.PaymentMethod)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.PaymentTime).HasColumnType("datetime");

                entity.HasOne(d => d.Invoice)
                    .WithMany(p => p.PaymentDetails)
                    .HasForeignKey(d => d.InvoiceId)
                    .HasConstraintName("FK__PaymentDe__Invoi__38996AB5");

                entity.HasOne(d => d.MemberCodeNavigation)
                    .WithMany(p => p.PaymentDetails)
                    .HasForeignKey(d => d.MemberCode)
                    .HasConstraintName("FK__PaymentDe__Membe__37A5467C");
            });

            modelBuilder.Entity<Room>(entity =>
            {
                entity.Property(e => e.RoomName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.RoomType).HasMaxLength(50);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.RoomTypeNavigation)
                    .WithMany(p => p.Room)
                    .HasForeignKey(d => d.RoomType)
                    .HasConstraintName("FK__Room__RoomType__2A4B4B5E");
            });

            modelBuilder.Entity<ServicesBill>(entity =>
            {
                entity.HasKey(e => e.BillNo)
                    .HasName("PK__Services__11F2841915646D58");

                entity.Property(e => e.Date).HasColumnType("datetime");

                entity.Property(e => e.ItemName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.MemberCodeNavigation)
                    .WithMany(p => p.ServicesBill)
                    .HasForeignKey(d => d.MemberCode)
                    .HasConstraintName("FK__ServicesB__Membe__30F848ED");

                entity.HasOne(d => d.ReservationCodeNavigation)
                    .WithMany(p => p.ServicesBill)
                    .HasForeignKey(d => d.ReservationCode)
                    .HasConstraintName("FK__ServicesB__Reser__31EC6D26");
            });

            modelBuilder.Entity<Staff>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Staff__1788CC4CFE182943");

                entity.HasIndex(e => e.Email)
                    .HasName("UQ__Staff__A9D10534AE59B8B2")
                    .IsUnique();

                entity.HasIndex(e => e.MobileNumber)
                    .HasName("UQ__Staff__250375B1766DE947")
                    .IsUnique();

                entity.Property(e => e.Address).HasMaxLength(50);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(55);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(55);

                entity.Property(e => e.MobileNumber)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Nic).HasColumnName("NIC");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(55);

                entity.Property(e => e.Role)
                    .IsRequired()
                    .HasMaxLength(55);
            });

            modelBuilder.Entity<TypeOfRoom>(entity =>
            {
                entity.HasKey(e => e.RoomType)
                    .HasName("PK__TypeOfRo__3A76E8C2758FD6AF");

                entity.Property(e => e.RoomType).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
