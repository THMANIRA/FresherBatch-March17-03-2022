﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IInvoiceData<Invoice> _invoiceRepository;

        public InvoiceController(IInvoiceData<Invoice> invoiceRepository)
        {
            _invoiceRepository = invoiceRepository;
        }
        [HttpGet("{InvoiceId}")]
        public async Task<ActionResult<Invoice>> GetInvoice(int InvoiceId)
        {
            return await _invoiceRepository.Get(InvoiceId);

        }
        [HttpPost]
        public async Task<Invoice> PostInvoice([FromBody] InvoiceData invoiceData)
        {
            var newInvoice = await _invoiceRepository.AddInvoice(invoiceData);
            return newInvoice;
        }
        [HttpDelete("{InvoiceId}")]
        public async Task<ActionResult> Delete(int InvoiceId)
        {
            var invoiceToDelete = await _invoiceRepository.Get(InvoiceId);
            if (invoiceToDelete == null)
            {
                return NotFound();

            }
            await _invoiceRepository.Delete(invoiceToDelete.InvoiceId);
            return NoContent();
        }
    }
}
