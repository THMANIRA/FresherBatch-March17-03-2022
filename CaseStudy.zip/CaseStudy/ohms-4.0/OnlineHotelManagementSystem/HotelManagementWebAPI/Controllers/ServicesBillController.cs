﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServicesBillController : ControllerBase
    {
        private readonly IServicesBillData<ServicesBill> _servicesBillRepository;

        public ServicesBillController(IServicesBillData<ServicesBill> servicesBillRepository)
        {
            _servicesBillRepository = servicesBillRepository;
        }
        [HttpGet("{BillNo}")]
        public async Task<ActionResult<ServicesBill>> GetBill(int BillNo)
        {
            return await _servicesBillRepository.Get(BillNo);

        }
        [HttpPost]
        public async Task<ServicesBill> PostGuest([FromBody] ServicesBillData servicesBillData)
        {
            var newBill = await _servicesBillRepository.AddBill(servicesBillData);
            return newBill;
        }
    }
}
