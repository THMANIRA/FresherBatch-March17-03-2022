﻿using System.Collections.Generic;
using System.Threading.Tasks;
using HotelManagementWebAPI.Models;
using HotelManagementWebAPI.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IStaffRepository _staffRepository;

        public StaffController(IStaffRepository staffRepository)
        {
            _staffRepository = staffRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<Staff>> GetStaffs()
        {
            return await _staffRepository.GetStaffs();

        }
        [HttpPost]
        public async Task<ActionResult<Staff>> PostGuests([FromBody] Staff staff)
        {
            var newStaff = await _staffRepository.Create(staff);
            return CreatedAtAction(nameof(GetStaffs), new { userId = newStaff }, newStaff);
        }

        [HttpPut]
        public async Task<ActionResult> PutStaffs(int userId, [FromBody] Staff staff)
        {
            if (userId != staff.UserId)
            {
                return BadRequest();
            }
            await _staffRepository.Update(staff);
            return NoContent();
        }

        [HttpDelete("{UserId}")]
        public async Task<ActionResult> Delete(int UserId)
        {
            var guestToDelete = await _staffRepository.Get(UserId);
            if (guestToDelete == null)
            {
                return NotFound();

            }
            await _staffRepository.Delete(guestToDelete.UserId);
            return NoContent();
        }
        [HttpGet("{UserId}")]
        public async Task<ActionResult<Staff>> GetStaff(int UserId)
        {
            return await _staffRepository.Get(UserId);

        }
    }
}
