﻿using System.Threading.Tasks;
using HotelManagementWebAPI.Data;
using HotelManagementWebAPI.Interface;
using HotelManagementWebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private readonly IRoomData<Room> _roomRepository;

        public RoomController(IRoomData<Room> roomRepository)
        {
            _roomRepository = roomRepository;
        }
        [HttpPost]
        public async Task<Room> PostRoom([FromBody] RoomData roomData)
        {
            var newroom = await _roomRepository.AddRoom(roomData);
            return newroom;
        }
        [HttpGet("{roomId}")]
        public async Task<Room> GetRoom(int roomId)
        {
            return await _roomRepository.Get(roomId);
        }
    }
}
