import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dashboards',
  templateUrl: './dashboards.component.html',
  styleUrls: ['./dashboards.component.scss']
})
export class DashboardsComponent implements OnInit {

  routeParameter:any;
  loggedInUserRole:any;

  constructor(private activeRoute: ActivatedRoute, public router:Router) { 
  }
  userLogout(){
    localStorage.clear();
    this.router.navigate(['/Home']);
  }

  ngOnInit(): void {
    this.loggedInUserRole = localStorage.getItem('loginUserRole');
    this.activeRoute.params.subscribe(routeParams => {
      this.routeParameter = routeParams['id'];
    });
  }

}
