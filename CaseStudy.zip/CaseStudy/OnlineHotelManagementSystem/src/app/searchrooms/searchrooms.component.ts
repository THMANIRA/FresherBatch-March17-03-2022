import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchrooms',
  templateUrl: './searchrooms.component.html',
  styleUrls: ['./searchrooms.component.css']
})
export class SearchroomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
