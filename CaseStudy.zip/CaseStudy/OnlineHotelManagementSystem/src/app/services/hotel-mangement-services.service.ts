import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelMangementServicesService {

  constructor(private http:HttpClient) { }

  AddUser(userObj:any) {
    return this.http.post("/api/Staff", userObj)
  }
  updateUser(id:any,userObj:any) {
    return this.http.put("/api/Staff/"+id, userObj)
  }
  getUsers(){
    return this.http.get("/api/Staff");
  }
  deleteUser(id:any){
    return this.http.delete("/api/Staff/"+id)
  }
  checkLoginData(userLoginObj:any){
    return this.http.post("/api/Login", userLoginObj)
  }
  AddGuest(guestObj:any){
    return this.http.post("/api/Guest", guestObj)
  }
  AddRates(setratesObj:any){
    return this.http.post("/api/TypeOfRoom", setratesObj)
  }
  AddInventory(inventoryObj:any){
    return this.http.post("/api/Inventory", inventoryObj)
  }
  AddRoomdetails(roomdetailsObj:any){
    return this.http.post("/api/Room",roomdetailsObj)
  }
}
