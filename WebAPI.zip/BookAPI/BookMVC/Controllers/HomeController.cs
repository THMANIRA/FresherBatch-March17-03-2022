﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using BookMVC.Helper;
using BookMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace BookMVC.Controllers
{
    public class HomeController : Controller
    {
        BookHelper bookhelper=new BookHelper();

        public async Task<IActionResult> Index()
        {
            List<BookData> books = new List<BookData>();
            HttpClient client=bookhelper.Initial();
            HttpResponseMessage res =await client.GetAsync("api/Book");
            if (res.IsSuccessStatusCode)
            {
               var results= res.Content.ReadAsStringAsync().Result;
                books = JsonConvert.DeserializeObject<List<BookData>>(results);

            }
            return View(books);
        }

        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(BookData book)
        {
            HttpClient client = bookhelper.Initial();
            var posttask = client.PostAsJsonAsync<BookData>("api/Book", book);
            posttask.Wait();
            var result = posttask.Result;
            if (result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            return View();
        }

        public async Task<IActionResult> Details(int Id)
        {
            var book = new BookData();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/Book/{Id}");
            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                book = JsonConvert.DeserializeObject<BookData>(results);
            }
            return View(book);
        }
        public async Task<IActionResult> Delete(int Id)
        {
            var book = new BookData();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.DeleteAsync($"api/Book/{Id}");
            return RedirectToAction("Index");
        }
        public async Task<ActionResult> Edit(int Id)
        {
            var book = new BookData();
            HttpClient client = bookhelper.Initial();
            HttpResponseMessage res = await client.GetAsync($"api/Book/{Id}");



            if (res.IsSuccessStatusCode)
            {
                var results = res.Content.ReadAsStringAsync().Result;
                book = JsonConvert.DeserializeObject<BookData>(results);
            }
            return View(book);
        }
        [HttpPost]
        public IActionResult Edit(BookData book)
        {
            HttpClient client = bookhelper.Initial();
            var putTask = client.PostAsJsonAsync<BookData>("api/Book", book);
            putTask.Wait();

            var result = putTask.Result;

            if (result.IsSuccessStatusCode)
            {



                return RedirectToAction("Index");
            }

            return View();
        }






























        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
